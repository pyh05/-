using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterManager : MonoBehaviour
{
    [SerializeField] private Transform startPos;
    [SerializeField] private Transform endPos;

    [SerializeField] private Transform[] wayPointTrans;

    [SerializeField] private Monster monster;

    float spawnTimer = 0;
    public int spawnCnt = 0;

    // Update is called once per frame
    void Update()
    {
        spawnTimer += Time.deltaTime;
        if (spawnTimer > 2f && spawnCnt < 20)
        {
            spawnTimer = 0f;

            Transform[] trans = new Transform[6];
            trans[0] = startPos;
            trans[1] = endPos;

            trans[2] = wayPointTrans[0];
            trans[3] = wayPointTrans[1];
            trans[4] = wayPointTrans[2];
            trans[5] = wayPointTrans[3];

            Monster m = Instantiate(monster, transform);
            m.SetPosition(trans);
            m.SetManager(this);
            spawnCnt++;
        }
    }
}
