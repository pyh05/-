using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour
{
    public enum AttackType
    {
        Single,
        Multi,

    }
    AttackType atkType = AttackType.Single;

    private Vector3 offset = Vector3.zero;
    int atkCount = 3;

    [SerializeField] private Transform[] dices;

    [HideInInspector] public float atkTime = 2f;
    List<Monster> monList = new List<Monster>();
    public static Unit Instance;


    int level = 0;

    public int Level 
    { 
        get { return level; }
        set 
        {
            level = value;
            foreach (var item in dices)
            {
                item.gameObject.SetActive(false);
            }
            dices[level - 1].gameObject.SetActive(true);
        } 
    }

    int atkOrderCnt = 0;
    Vector3 clickVec3 = Vector3.zero;
    Unit temptileUnit;
    // Start is called before the first frame update
    void Start()
    {
        Level = 1;
        // offset = transform.position - Camera.main.ScreenToWorldPoint(Input.mousePosition);
        atkDelayTime = atkTime / (float)Level;
        // InvokeRepeating("DiceFire", 0.2f, delay);
    }
    private void Awake()
    {
        Instance = this;
    }
    private void OnMouseDown()
    {
        Debug.Log("Click");
        offset = transform.position - Camera.main.ScreenToWorldPoint(Input.mousePosition);
        clickVec3 = transform.position;
        Transform tileTrans = TileManager.Instance.DownCheck(transform);
        temptileUnit = tileTrans.GetComponent<TileBox>().unit;
        tileTrans.GetComponent<TileBox>().unit = null;

    }

    private void OnMouseUp()
    {
        Debug.Log("UnClick");

        Transform tileTrans = TileManager.Instance.DownCheck(transform);
        if (tileTrans.GetComponent<TileBox>().unit == null)
        {
            transform.position = tileTrans.position;
            tileTrans.GetComponent<TileBox>().unit = this;
        }
        else
        {
            transform.position = clickVec3;
            if (tileTrans.GetComponent<TileBox>().unit.Level == temptileUnit.level)
            {
                tileTrans.GetComponent<TileBox>().unit.Level++;
                Destroy(gameObject);
            }
        }

        clickVec3 = offset = Vector3.zero;
        
    }

    public float atkTimer = 0;
    public float atkDelayTime = 0;
    // Update is called once per frame
    void Update()
    {
        if (offset != Vector3.zero)
        {
            Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position = new Vector3(pos.x + offset.x, pos.y + offset.y, pos.z + offset.z);
        }

        Collider2D hit = Physics2D.OverlapCircle(transform.position, 1.5f);
        atkTimer += Time.deltaTime;
        
        if (hit.tag.Equals("monster"))
        {
            if (atkTimer > atkDelayTime)
            {
                DiceFire(hit.transform);
                atkTimer = 0;

            }

        }
        
        /*
        Collider2D[] hit = Physics2D.OverlapCircleAll(transform.position, 1.5f);
        if (hit.Length != 0)
        {
            if (atkType == AttackType.Single)
            {
                monList.Add(hit[0].GetComponent<Monster>());
            }
            else
            {
                int count = 0;
                foreach (var item in hit)
                {
                    if (count < atkCount)
                    {
                        monList.Add(item.GetComponent<Monster>());
                    }
                }
            }
        }
        */

    }

    public void DiceFire(Transform target)
    {
        dices[Level - 1].GetChild(atkOrderCnt).GetComponent<DotManager>().Attack(target);
        atkOrderCnt++;
        if (atkOrderCnt >= dices[Level - 1].childCount)
        {
            atkOrderCnt = 0;
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, 1.5f);
    }

   

}
