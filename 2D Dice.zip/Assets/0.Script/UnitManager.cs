using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitManager : MonoBehaviour
{
    [SerializeField] private Unit unit;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnCreate()
    {
        TileBox tile = TileManager.Instance.CreateCheck();
        if (tile != null)
        {
            Unit u = Instantiate(unit, tile.transform.position, Quaternion.identity);
            TileManager.Instance.SetTileUnit(tile, u);
        }
    }
}
