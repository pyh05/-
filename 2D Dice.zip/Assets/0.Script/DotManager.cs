using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DotManager : MonoBehaviour
{
    [SerializeField] private Dot dot;
    private Unit unit;

    private void Start()
    {
        if (unit == null)
        {
            unit = Unit.Instance;
        }
    }
    public void Attack(Transform target)
    {
        Vector2 vec = transform.position - target.position;
        float angle = Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle + 90, Vector3.forward);

        Dot d = Instantiate(dot, transform);
        d.SetTarget(target);

    }
   
}
