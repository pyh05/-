using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dot : MonoBehaviour
{
    public float speed;
    Transform target;

    private Vector3 velocity = Vector3.zero;
    public float smoothTime = 0.3f;
    float deleteTimer;
    // Update is called once per frame
    void Update()
    {
        deleteTimer += Time.deltaTime;
        try
        {
            transform.Translate(Vector3.up * Time.deltaTime * speed);

            if (Vector3.Distance(transform.position, target.position) < 0.3f)
            {
                target.GetComponent<Monster>().Hit(24);
                Destroy(gameObject);
            }
        }
        catch (MissingReferenceException e)
        {

            Destroy(gameObject);
        }


        if (deleteTimer > 0.6f)
        {
            Destroy(gameObject);
        }
    }

    public void SetTarget(Transform target)
    {
        this.target = target;
    }
}
