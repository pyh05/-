using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using TMPro;

public class Monster : MonoBehaviour
{
    public class MonsterData
    {
        public int HP { get; set; }
    }

    [SerializeField] private Transform startPos;
    [SerializeField] private Transform endPos;

    [SerializeField] private Transform[] wayPointTrans;
    [SerializeField] private TMP_Text damageTxt;

    private MonsterManager monManager;
    private Vector3[] wayPoints = new Vector3[5];

    protected MonsterData data = new MonsterData();


    // Start is called before the first frame update
    void Start()
    {
        transform.localPosition = startPos.localPosition;
        GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, 0f);
        data.HP = 100;
        Statto();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void SetPosition(Transform[] trans)
    {
        startPos = trans[0];
        endPos = trans[1];

        wayPointTrans[0] = trans[2];
        wayPointTrans[1] = trans[3];
        wayPointTrans[2] = trans[4];
        wayPointTrans[3] = trans[5];
    }

    void Statto()
    {
        DOTween.Init(false, true, LogBehaviour.ErrorsOnly);

        wayPoints.SetValue(wayPointTrans[0].position, 0);
        wayPoints.SetValue(wayPointTrans[1].position, 1);
        wayPoints.SetValue(wayPointTrans[2].position, 2);
        wayPoints.SetValue(wayPointTrans[3].position, 3);
        wayPoints.SetValue(wayPointTrans[0].position, 4);



        GetComponent<SpriteRenderer>()
            .DOColor(Color.white, 0.5f);

        // ���Ͱ� ���۵ɶ� ���������� �̵�
        transform
            .DOMoveY(endPos.position.y, 2f)
            .OnComplete(() =>
            {
                transform
                    .DOMoveX(wayPointTrans[0].position.x, 3f)
                    .OnComplete(() =>
                    {
                        transform
                            .DOPath(wayPoints, 20f)
                            .SetLoops(-1, LoopType.Restart)
                            .SetEase(Ease.Linear);
                    });
                
            });
    }

    public void Hit(int damage)
    {
        damageTxt.text = damage.ToString();

        damageTxt.transform.DOMoveY(0.2f, 0.3f)
            .SetEase(Ease.InElastic)
            .OnComplete(() => 
            { 
                damageTxt.text = "";
                damageTxt.transform.localPosition = new Vector3(0f, 400f, 0f);

                data.HP -= damage;
                if (data.HP <= 0)
                {
                    Destroy(gameObject);
                    monManager.spawnCnt--;
                }
            });
    }

    public void SetManager(MonsterManager m)
    {
        monManager = m;
    }
}
