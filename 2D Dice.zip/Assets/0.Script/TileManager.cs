using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileManager : MonoBehaviour
{

    [SerializeField] Transform[] tileTrans;

    public static TileManager Instance;

    public Transform DownCheck(Transform trans)
    {
        float dis = 100;
        Transform target = null;

        Check(ref dis, ref trans, ref target, tileTrans);

        return target;
    }

    public void Check(ref float dis, ref Transform trans, ref Transform target, Transform[] transforms)
    {
        foreach (var item in transforms)
        {
            float distance = Vector3.Distance(trans.position, item.position);
            if (distance < dis)
            {
                dis = distance;
                target = item;
            }
        }
    }

    public TileBox CreateCheck()
    {
        TileBox tile = CreateCheck(tileTrans);
        if (tile != null)
        {
            return tile;
        }

        return null;
    }

    TileBox CreateCheck(Transform[] transforms)
    {
        foreach (var item in transforms)
        {
            if (item.GetComponent<TileBox>().unit == null)
            {
                return item.GetComponent<TileBox>();
            }
        }

        return null;
    }

    public void SetTileUnit(TileBox tile, Unit unit)
    {
        foreach (var item in tileTrans)
        {
            if (item.GetComponent<TileBox>() == tile)
            {
                item.GetComponent<TileBox>().unit = unit;
            }
        }
    }

    private void Awake()
    {
        Instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
