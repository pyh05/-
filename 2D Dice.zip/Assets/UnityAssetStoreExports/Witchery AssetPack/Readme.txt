The Assets are spread through 12 Sprite Sheets, each with a specific type.
The Example Scene contains some os the assets layedout as an example of what they may look like in a game scene.